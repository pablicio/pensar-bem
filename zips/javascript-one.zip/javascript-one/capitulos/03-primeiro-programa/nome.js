console.log(situacao);
