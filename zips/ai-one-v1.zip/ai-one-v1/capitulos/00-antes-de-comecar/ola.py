print("Rotação Discos")
